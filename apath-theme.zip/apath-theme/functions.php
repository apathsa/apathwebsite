<?php
/**
 * Apath theme functions.
 * This theme renders a self-contained, JavaScript-driven single page
 * (Tailwind CSS via CDN + vanilla JS) with no page reloads between sections.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function apath_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
}
add_action( 'after_setup_theme', 'apath_theme_setup' );

/**
 * The theme is intentionally self-contained: Tailwind CSS and Lucide Icons
 * are loaded via CDN directly inside header.php, and all page content/text
 * (Arabic + English) lives in the inline script in index.php.
 */
