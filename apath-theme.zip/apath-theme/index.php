<?php
/**
 * Apath theme — single-page template.
 * The entire site (Home, Expertise, Services, Projects, Blog, Contact) is
 * rendered client-side by JavaScript; this template only provides the
 * WordPress-compliant document shell and mount point.
 */
get_header();
?>

<div id="root"></div>

<script>
/* ======================= TRANSLATION DICTIONARY ======================= */
const dict = {
  ar: {
    dir: "rtl",
    brand: "أباث",
    brandSub: "APATH",
    nav: { home: "الرئيسية", expertise: "الخبرات", services: "الخدمات", projects: "المشاريع", blog: "المدونة", contact: "تواصل معنا" },
    cta: { primary: "ابدأ مشروعك", secondary: "تعرف علينا أكثر", request: "اطلب الخدمة", readMore: "اقرأ المزيد", sendMsg: "إرسال الرسالة", viewProject: "عرض المشروع" },
    home: {
      heroTag: "شريكك في رسم الطريق الرقمي",
      heroTitle: "نرسم لك الطريق نحو التحول الرقمي",
      heroDesc: "أباث شركة استشارات وحلول تقنية تُرافق مؤسستك خطوة بخطوة، من الفكرة الأولى حتى الإطلاق والنمو المستدام.",
      stats: [ { n: "+120", l: "مشروع منجز" }, { n: "+45", l: "عميل حول العالم" }, { n: "9", l: "سنوات خبرة" }, { n: "98%", l: "رضا العملاء" } ],
      expertiseTitle: "خبرة تصنع الفرق",
      expertiseDesc: "فريق متعدد التخصصات يجمع بين الاستراتيجية والتقنية والتصميم لتحويل أهدافك إلى واقع ملموس.",
      expertiseCards: [
        { icon: "target", t: "استراتيجية واضحة", d: "نبني خارطة طريق مبنية على بياناتك وسوقك." },
        { icon: "layers", t: "تنفيذ متكامل", d: "فرق تعمل بتناغم من الفكرة حتى الإطلاق." },
        { icon: "rocket", t: "نمو مستمر", d: "دعم وتحسين مستمر بعد الإطلاق." },
      ],
      servicesTitle: "خدماتنا الأساسية",
      servicesDesc: "حلول متكاملة مصممة خصيصاً لاحتياجات عملك.",
      projectsTitle: "لمحة من أعمالنا",
      projectsDesc: "نماذج من المشاريع التي رافقنا عملاءنا في تنفيذها.",
      viewAll: "عرض جميع المشاريع",
    },
    expertise: {
      title: "خبراتنا ومنهجيتنا",
      subtitle: "نتبع منهجية واضحة ومدروسة في كل مشروع نعمل عليه، لنضمن نتائج قابلة للقياس ومستدامة.",
      methodologyTitle: "منهجية العمل — خطوة بخطوة",
      steps: [
        { t: "الاكتشاف", d: "نبدأ بفهم عميق لأهداف عملك وتحدياته والسوق المستهدف." },
        { t: "التصميم", d: "نضع استراتيجية ونماذج أولية توازن بين التجربة والوظيفة." },
        { t: "التطوير", d: "نبني الحل باستخدام أحدث التقنيات وأفضل الممارسات." },
        { t: "الإطلاق", d: "ننشر الحل بعد اختبارات دقيقة تضمن الجودة والاستقرار." },
        { t: "الدعم والنمو", d: "نرافقك بعد الإطلاق بالتحسين المستمر والدعم الفني." },
      ],
      strengthsTitle: "نقاط قوتنا",
      strengths: [
        { t: "فرق متخصصة", d: "خبراء في التقنية والتصميم والاستراتيجية." },
        { t: "التزام بالمواعيد", d: "تسليم دقيق يحترم جدول عملك." },
        { t: "شفافية كاملة", d: "تقارير دورية وتواصل مستمر في كل مرحلة." },
        { t: "حلول مرنة", d: "قابلة للتوسع مع نمو أعمالك." },
      ],
      numbersTitle: "أرقام تتحدث عنا",
      numbers: [
        { n: "+120", l: "مشروع منجز", icon: "flag" },
        { n: "+45", l: "عميل حول العالم", icon: "users" },
        { n: "9", l: "سنوات خبرة", icon: "award" },
        { n: "16", l: "دولة نخدمها", icon: "map-pin" },
      ],
    },
    services: {
      title: "خدماتنا",
      subtitle: "حلول تقنية واستشارية متكاملة تغطي رحلتك الرقمية بالكامل.",
      list: [
        { icon: "code-2", t: "تطوير البرمجيات", d: "بناء تطبيقات ويب وموبايل مخصصة بجودة عالية وأداء موثوق." },
        { icon: "cloud", t: "الحلول السحابية", d: "ترحيل وإدارة بنيتك التحتية على أفضل منصات الحوسبة السحابية." },
        { icon: "shield-check", t: "الأمن السيبراني", d: "حماية أصولك الرقمية عبر تقييمات مخاطر وحلول أمنية متقدمة." },
        { icon: "target", t: "الاستشارات الرقمية", d: "خطط تحول رقمي مبنية على تحليل عميق لواقع مؤسستك." },
        { icon: "pen-tool", t: "تصميم تجربة المستخدم", d: "واجهات جذابة وسهلة الاستخدام تعزز رضا عملائك." },
        { icon: "bar-chart-3", t: "تحليل البيانات", d: "تحويل بياناتك إلى قرارات ذكية عبر لوحات تحكم تفاعلية." },
      ],
    },
    projects: {
      title: "أعمالنا",
      subtitle: "معرض يضم نماذج مختارة من المشاريع التي أنجزناها لعملائنا.",
      filters: ["الكل", "تطوير ويب", "تطبيقات موبايل", "حلول سحابية", "تصميم"],
      list: [
        { t: "منصة تجارة إلكترونية", cat: "تطوير ويب", d: "منصة بيع متكاملة بتصميم عصري وأداء عالي.", client: "متجر لمسة" },
        { t: "تطبيق إدارة اللياقة", cat: "تطبيقات موبايل", d: "تطبيق ذكي لمتابعة التمارين والتغذية اليومية.", client: "فيت لايف" },
        { t: "ترحيل بنية سحابية", cat: "حلول سحابية", d: "نقل بنية تحتية كاملة إلى السحابة بأمان تام.", client: "دار المال" },
        { t: "هوية بصرية ومنصة", cat: "تصميم", d: "إعادة تصميم الهوية البصرية وواجهة الموقع الإلكتروني.", client: "أفق العقارية" },
        { t: "نظام حجوزات ذكي", cat: "تطوير ويب", d: "نظام حجز وإدارة مواعيد متكامل مع لوحة تحكم.", client: "كلينك برو" },
        { t: "تطبيق توصيل الطلبات", cat: "تطبيقات موبايل", d: "تطبيق توصيل بتتبع لحظي وتجربة سلسة للمستخدم.", client: "سريع اكسبريس" },
      ],
    },
    blog: {
      title: "المدونة",
      subtitle: "مقالات ورؤى حول التقنية والتحول الرقمي وريادة الأعمال.",
      list: [
        { t: "كيف تختار شريكك التقني المناسب؟", excerpt: "دليل عملي لاختيار الشريك التقني الذي يواكب طموحاتك.", author: "سارة العتيبي", date: "12 يوليو 2026", cat: "استشارات" },
        { t: "مستقبل الحوسبة السحابية في المنطقة", excerpt: "نظرة على اتجاهات تبني السحابة في الشرق الأوسط.", author: "خالد المري", date: "2 يوليو 2026", cat: "سحابة" },
        { t: "خمس علامات تدل على حاجتك لتحول رقمي", excerpt: "مؤشرات عملية تساعدك على تقييم جاهزية مؤسستك.", author: "لينا حداد", date: "24 يونيو 2026", cat: "تحول رقمي" },
        { t: "تجربة المستخدم كميزة تنافسية", excerpt: "كيف يمكن للتصميم الجيد أن يرفع من قيمة منتجك.", author: "عمر الشريف", date: "15 يونيو 2026", cat: "تصميم" },
      ],
    },
    contact: {
      title: "تواصل معنا",
      subtitle: "يسعدنا الاستماع إلى فكرتك، راسلنا وسنعاود التواصل خلال 24 ساعة.",
      formTitle: "أرسل لنا رسالة",
      name: "الاسم الكامل", email: "البريد الإلكتروني", phone: "رقم الهاتف", subject: "الموضوع", message: "رسالتك",
      infoTitle: "معلومات التواصل",
      address: "الرياض، المملكة العربية السعودية",
      hours: "الأحد - الخميس: 9 صباحاً - 6 مساءً",
      success: "تم إرسال رسالتك بنجاح، سنتواصل معك قريباً.",
    },
    footer: { desc: "أباث — شريكك الموثوق في التحول الرقمي وبناء الحلول التقنية المستدامة.", quickLinks: "روابط سريعة", contactInfo: "تواصل معنا", rights: "جميع الحقوق محفوظة" },
  },
  en: {
    dir: "ltr",
    brand: "Apath",
    brandSub: "أباث",
    nav: { home: "Home", expertise: "Expertise", services: "Services", projects: "Projects", blog: "Blog", contact: "Contact" },
    cta: { primary: "Start your project", secondary: "Learn more about us", request: "Request service", readMore: "Read more", sendMsg: "Send message", viewProject: "View project" },
    home: {
      heroTag: "Your partner in charting the digital path",
      heroTitle: "We chart the path to your digital transformation",
      heroDesc: "Apath is a technology consulting and solutions company that walks alongside your organization, from the first idea to launch and sustainable growth.",
      stats: [ { n: "120+", l: "Projects delivered" }, { n: "45+", l: "Clients worldwide" }, { n: "9", l: "Years of experience" }, { n: "98%", l: "Client satisfaction" } ],
      expertiseTitle: "Expertise that makes a difference",
      expertiseDesc: "A multidisciplinary team blending strategy, technology and design to turn your goals into reality.",
      expertiseCards: [
        { icon: "target", t: "Clear strategy", d: "We build a roadmap grounded in your data and market." },
        { icon: "layers", t: "Integrated execution", d: "Teams working in sync from idea to launch." },
        { icon: "rocket", t: "Ongoing growth", d: "Ongoing support and improvement after launch." },
      ],
      servicesTitle: "Our core services",
      servicesDesc: "Integrated solutions built around your business needs.",
      projectsTitle: "A glimpse of our work",
      projectsDesc: "A selection of projects we delivered alongside our clients.",
      viewAll: "View all projects",
    },
    expertise: {
      title: "Our expertise & methodology",
      subtitle: "We follow a clear, deliberate methodology on every project to guarantee measurable, sustainable results.",
      methodologyTitle: "Our process, step by step",
      steps: [
        { t: "Discover", d: "We start with a deep understanding of your goals, challenges and target market." },
        { t: "Design", d: "We craft a strategy and prototypes that balance experience and function." },
        { t: "Develop", d: "We build the solution using the latest technologies and best practices." },
        { t: "Launch", d: "We ship after rigorous testing that guarantees quality and stability." },
        { t: "Support & grow", d: "We stay with you after launch for continuous improvement and support." },
      ],
      strengthsTitle: "Our strengths",
      strengths: [
        { t: "Specialized teams", d: "Experts across technology, design and strategy." },
        { t: "On-time delivery", d: "Precise delivery that respects your timeline." },
        { t: "Full transparency", d: "Regular reporting and constant communication at every stage." },
        { t: "Flexible solutions", d: "Built to scale as your business grows." },
      ],
      numbersTitle: "Numbers that speak for us",
      numbers: [
        { n: "120+", l: "Projects delivered", icon: "flag" },
        { n: "45+", l: "Clients worldwide", icon: "users" },
        { n: "9", l: "Years of experience", icon: "award" },
        { n: "16", l: "Countries served", icon: "map-pin" },
      ],
    },
    services: {
      title: "Our services",
      subtitle: "Integrated technology and consulting solutions covering your entire digital journey.",
      list: [
        { icon: "code-2", t: "Software development", d: "Custom web and mobile apps built with quality and reliable performance." },
        { icon: "cloud", t: "Cloud solutions", d: "Migrate and manage your infrastructure on leading cloud platforms." },
        { icon: "shield-check", t: "Cybersecurity", d: "Protect your digital assets with risk assessments and advanced security solutions." },
        { icon: "target", t: "Digital consulting", d: "Transformation roadmaps built on deep analysis of your organization." },
        { icon: "pen-tool", t: "UX/UI design", d: "Engaging, easy-to-use interfaces that boost customer satisfaction." },
        { icon: "bar-chart-3", t: "Data analytics", d: "Turn your data into smart decisions through interactive dashboards." },
      ],
    },
    projects: {
      title: "Our work",
      subtitle: "A gallery of selected projects we delivered for our clients.",
      filters: ["All", "Web development", "Mobile apps", "Cloud solutions", "Design"],
      list: [
        { t: "E-commerce platform", cat: "Web development", d: "A full-featured storefront with a modern design and strong performance.", client: "Lamsa Store" },
        { t: "Fitness tracking app", cat: "Mobile apps", d: "A smart app for tracking workouts and daily nutrition.", client: "FitLife" },
        { t: "Cloud infrastructure migration", cat: "Cloud solutions", d: "Migrating a full infrastructure to the cloud with complete security.", client: "Dar Al-Mal" },
        { t: "Brand identity & platform", cat: "Design", d: "A full brand identity refresh and website interface redesign.", client: "Ufuq Real Estate" },
        { t: "Smart booking system", cat: "Web development", d: "An integrated booking and scheduling system with an admin dashboard.", client: "Clinic Pro" },
        { t: "Delivery app", cat: "Mobile apps", d: "A delivery app with live tracking and a seamless user experience.", client: "Sarie Express" },
      ],
    },
    blog: {
      title: "Blog",
      subtitle: "Articles and insights on technology, digital transformation and entrepreneurship.",
      list: [
        { t: "How to choose the right tech partner", excerpt: "A practical guide to picking a technology partner that matches your ambitions.", author: "Sarah Al-Otaibi", date: "Jul 12, 2026", cat: "Consulting" },
        { t: "The future of cloud computing in the region", excerpt: "A look at cloud adoption trends across the Middle East.", author: "Khaled Al-Marri", date: "Jul 2, 2026", cat: "Cloud" },
        { t: "Five signs you need a digital transformation", excerpt: "Practical indicators to assess your organization's readiness.", author: "Lina Haddad", date: "Jun 24, 2026", cat: "Digital transformation" },
        { t: "User experience as a competitive edge", excerpt: "How great design can raise the value of your product.", author: "Omar Al-Sharif", date: "Jun 15, 2026", cat: "Design" },
      ],
    },
    contact: {
      title: "Get in touch",
      subtitle: "We'd love to hear your idea. Reach out and we'll get back to you within 24 hours.",
      formTitle: "Send us a message",
      name: "Full name", email: "Email address", phone: "Phone number", subject: "Subject", message: "Your message",
      infoTitle: "Contact information",
      address: "Riyadh, Saudi Arabia",
      hours: "Sun - Thu: 9am - 6pm",
      success: "Your message has been sent. We'll be in touch shortly.",
    },
    footer: { desc: "Apath — your trusted partner in digital transformation and sustainable technology solutions.", quickLinks: "Quick links", contactInfo: "Contact info", rights: "All rights reserved" },
  },
};

/* ======================= APP STATE ======================= */
const state = {
  lang: "ar",
  theme: "light",
  page: "home",
  menuOpen: false,
  projectFilter: null,
  contactSent: false,
};

const PAGES = ["home", "expertise", "services", "projects", "blog", "contact"];
const GRADIENTS = ["from-amber-500 to-amber-700", "from-teal-500 to-teal-700", "from-slate-500 to-slate-700", "from-rose-400 to-amber-600"];

function t() { return dict[state.lang]; }
function isRTL() { return t().dir === "rtl"; }
function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

/* ======================= REUSABLE MARKUP ======================= */
function logoHTML() {
  const T = t();
  return `
    <div class="flex items-center gap-2 shrink-0">
      <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-600 to-amber-800 dark:from-amber-500 dark:to-amber-700 flex items-center justify-center">
        <i data-lucide="route" class="w-5 h-5 text-white"></i>
      </div>
      <div class="leading-tight">
        <p class="font-bold text-lg text-slate-900 dark:text-white">${T.brand}</p>
        <p class="text-[10px] tracking-[0.2em] text-teal-700 dark:text-teal-400 font-semibold">${T.brandSub}</p>
      </div>
    </div>`;
}

function pathLineSVG(colorClass) {
  return `
    <svg viewBox="0 0 800 60" class="w-full h-auto ${colorClass}" preserveAspectRatio="none">
      <path d="M0,30 C150,0 250,60 400,30 C550,0 650,60 800,30" fill="none" stroke="currentColor" stroke-width="2" stroke-dasharray="1 14" stroke-linecap="round"/>
    </svg>`;
}

function sectionHeadingHTML(eyebrow, title, desc) {
  const align = isRTL() ? "text-right" : "text-left";
  return `
    <div class="max-w-2xl ${align} mx-auto md:mx-0">
      ${eyebrow ? `<p class="text-xs font-bold tracking-widest text-amber-700 dark:text-amber-400 uppercase mb-3">${esc(eyebrow)}</p>` : ""}
      <h2 class="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white">${esc(title)}</h2>
      ${desc ? `<p class="mt-4 text-slate-600 dark:text-slate-400 leading-relaxed">${esc(desc)}</p>` : ""}
    </div>`;
}

function headerHTML() {
  const T = t();
  const navArrowIcon = isRTL() ? "chevron-left" : "chevron-right";
  const navItems = PAGES.map((p) => `
    <button data-action="setPage" data-value="${p}"
      class="px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
        state.page === p
          ? "text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/10"
          : "text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60"
      }">${T.nav[p]}</button>`).join("");

  const mobileNavItems = PAGES.map((p) => `
    <button data-action="setPage" data-value="${p}"
      class="w-full text-start px-3 py-2.5 rounded-lg text-sm font-medium ${
        state.page === p ? "text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/10" : "text-slate-600 dark:text-slate-300"
      }">${T.nav[p]}</button>`).join("");

  return `
  <header class="sticky top-0 z-50 bg-white/90 dark:bg-slate-950/90 backdrop-blur border-b border-slate-200 dark:border-slate-800">
    <div class="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between gap-4">
      <button data-action="setPage" data-value="home" class="cursor-pointer">${logoHTML()}</button>

      <nav class="hidden lg:flex items-center gap-1">${navItems}</nav>

      <div class="hidden lg:flex items-center gap-2">
        <button data-action="toggleLang" class="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors">
          <i data-lucide="globe" class="w-4 h-4"></i> ${state.lang === "ar" ? "EN" : "ع"}
        </button>
        <button data-action="toggleTheme" class="p-2.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors" aria-label="toggle theme">
          <i data-lucide="${state.theme === "light" ? "moon" : "sun"}" class="w-4 h-4"></i>
        </button>
        <button data-action="setPage" data-value="contact" class="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-500 transition-colors">
          ${T.cta.primary} <i data-lucide="${navArrowIcon}" class="w-4 h-4"></i>
        </button>
      </div>

      <button data-action="toggleMenu" class="lg:hidden p-2 text-slate-700 dark:text-slate-200">
        <i data-lucide="${state.menuOpen ? "x" : "menu"}" class="w-6 h-6"></i>
      </button>
    </div>

    ${state.menuOpen ? `
    <div class="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-5 py-4 space-y-1">
      ${mobileNavItems}
      <div class="flex items-center gap-2 pt-3 mt-2 border-t border-slate-200 dark:border-slate-800">
        <button data-action="toggleLang" class="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/60">
          <i data-lucide="globe" class="w-4 h-4"></i> ${state.lang === "ar" ? "English" : "العربية"}
        </button>
        <button data-action="toggleTheme" class="p-2.5 rounded-lg text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800/60">
          <i data-lucide="${state.theme === "light" ? "moon" : "sun"}" class="w-4 h-4"></i>
        </button>
      </div>
    </div>` : ""}
  </header>`;
}

function footerHTML() {
  const T = t();
  const links = PAGES.map((p) => `<li><button data-action="setPage" data-value="${p}" class="text-slate-400 hover:text-amber-400 transition-colors">${T.nav[p]}</button></li>`).join("");
  return `
  <footer class="bg-slate-950 dark:bg-black text-slate-300 border-t border-slate-900">
    <div class="max-w-6xl mx-auto px-5 py-14 grid md:grid-cols-3 gap-10">
      <div>
        ${logoHTML()}
        <p class="mt-4 text-sm text-slate-400 leading-relaxed max-w-xs">${T.footer.desc}</p>
      </div>
      <div>
        <p class="text-white font-semibold mb-4">${T.footer.quickLinks}</p>
        <ul class="space-y-2 text-sm">${links}</ul>
      </div>
      <div>
        <p class="text-white font-semibold mb-4">${T.footer.contactInfo}</p>
        <ul class="space-y-3 text-sm text-slate-400">
          <li class="flex items-center gap-2"><i data-lucide="map-pin" class="w-4 h-4 text-amber-500 shrink-0"></i>${T.contact.address}</li>
          <li class="flex items-center gap-2"><i data-lucide="phone" class="w-4 h-4 text-amber-500 shrink-0"></i><span dir="ltr">+966 11 234 5678</span></li>
          <li class="flex items-center gap-2"><i data-lucide="mail" class="w-4 h-4 text-amber-500 shrink-0"></i><span dir="ltr">hello@apath.co</span></li>
        </ul>
      </div>
    </div>
    <div class="border-t border-slate-900 py-5 text-center text-xs text-slate-500">© 2026 ${T.brand}. ${T.footer.rights}.</div>
  </footer>`;
}

/* ======================= PAGES ======================= */
function homePageHTML() {
  const T = t();
  const arrowIcon = isRTL() ? "arrow-left" : "arrow-right";

  const statsHTML = T.home.stats.map((s) => `
    <div class="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 text-center">
      <p class="text-3xl font-extrabold text-amber-700 dark:text-amber-400">${s.n}</p>
      <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">${s.l}</p>
    </div>`).join("");

  const expertiseCardsHTML = T.home.expertiseCards.map((c) => `
    <div class="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-amber-300 dark:hover:border-amber-700 transition-colors">
      <div class="w-11 h-11 rounded-xl bg-amber-50 dark:bg-amber-500/10 flex items-center justify-center mb-4">
        <i data-lucide="${c.icon}" class="w-5 h-5 text-amber-700 dark:text-amber-400"></i>
      </div>
      <p class="font-semibold text-slate-900 dark:text-white">${c.t}</p>
      <p class="mt-2 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">${c.d}</p>
    </div>`).join("");

  const servicesTeaserHTML = T.services.list.map((s) => `
    <div class="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800">
      <div class="w-11 h-11 rounded-xl bg-teal-50 dark:bg-teal-500/10 flex items-center justify-center mb-4">
        <i data-lucide="${s.icon}" class="w-5 h-5 text-teal-700 dark:text-teal-400"></i>
      </div>
      <p class="font-semibold text-slate-900 dark:text-white">${s.t}</p>
      <p class="mt-2 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">${s.d}</p>
    </div>`).join("");

  const projectsTeaserHTML = T.projects.list.slice(0, 3).map((p, i) => `
    <div class="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 group">
      <div class="h-36 bg-gradient-to-br ${GRADIENTS[i % GRADIENTS.length]} flex items-center justify-center">
        <i data-lucide="route" class="w-9 h-9 text-white/70"></i>
      </div>
      <div class="p-5 bg-white dark:bg-slate-900">
        <p class="text-xs font-semibold text-amber-700 dark:text-amber-400">${p.cat}</p>
        <p class="mt-1.5 font-semibold text-slate-900 dark:text-white">${p.t}</p>
        <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">${p.d}</p>
      </div>
    </div>`).join("");

  return `
  <div>
    <section class="relative overflow-hidden bg-gradient-to-b from-amber-50 to-white dark:from-slate-900 dark:to-slate-950">
      <div class="max-w-6xl mx-auto px-5 pt-20 pb-16 md:pt-28 md:pb-24 text-center">
        <span class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-teal-50 dark:bg-teal-500/10 text-teal-800 dark:text-teal-300 text-sm font-medium mb-6">
          <i data-lucide="compass" class="w-4 h-4"></i> ${T.home.heroTag}
        </span>
        <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 dark:text-white leading-tight max-w-4xl mx-auto">${T.home.heroTitle}</h1>
        <p class="mt-6 text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">${T.home.heroDesc}</p>
        <div class="mt-9 flex flex-wrap items-center justify-center gap-4">
          <button data-action="setPage" data-value="contact" class="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-500 text-white font-semibold transition-colors shadow-lg shadow-amber-700/20">
            ${T.cta.primary} <i data-lucide="${arrowIcon}" class="w-4 h-4"></i>
          </button>
          <button data-action="setPage" data-value="expertise" class="px-6 py-3.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors">
            ${T.cta.secondary}
          </button>
        </div>
      </div>
      <div class="text-amber-700/40 dark:text-amber-500/20 -mb-2">${pathLineSVG("")}</div>
      <div class="max-w-6xl mx-auto px-5 pb-16 grid grid-cols-2 md:grid-cols-4 gap-4">${statsHTML}</div>
    </section>

    <section class="py-20 bg-white dark:bg-slate-950">
      <div class="max-w-6xl mx-auto px-5">
        ${sectionHeadingHTML(T.nav.expertise, T.home.expertiseTitle, T.home.expertiseDesc)}
        <div class="mt-10 grid md:grid-cols-3 gap-6">${expertiseCardsHTML}</div>
      </div>
    </section>

    <section class="py-20 bg-slate-50 dark:bg-slate-900/40">
      <div class="max-w-6xl mx-auto px-5">
        ${sectionHeadingHTML(T.nav.services, T.home.servicesTitle, T.home.servicesDesc)}
        <div class="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">${servicesTeaserHTML}</div>
      </div>
    </section>

    <section class="py-20 bg-white dark:bg-slate-950">
      <div class="max-w-6xl mx-auto px-5">
        <div class="flex flex-wrap items-end justify-between gap-6">
          ${sectionHeadingHTML(T.nav.projects, T.home.projectsTitle, T.home.projectsDesc)}
          <button data-action="setPage" data-value="projects" class="flex items-center gap-2 text-amber-700 dark:text-amber-400 font-semibold text-sm">
            ${T.home.viewAll} <i data-lucide="${arrowIcon}" class="w-4 h-4"></i>
          </button>
        </div>
        <div class="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">${projectsTeaserHTML}</div>
      </div>
    </section>

    <section class="py-16 bg-slate-950 dark:bg-black">
      <div class="max-w-4xl mx-auto px-5 text-center">
        <h3 class="text-2xl md:text-3xl font-bold text-white">${T.home.heroTitle}</h3>
        <button data-action="setPage" data-value="contact" class="mt-6 inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold transition-colors">
          ${T.cta.primary} <i data-lucide="${arrowIcon}" class="w-4 h-4"></i>
        </button>
      </div>
    </section>
  </div>`;
}

function expertisePageHTML() {
  const T = t();
  const stepsHTML = T.expertise.steps.map((s, i) => `
    <div class="relative z-10 text-center md:text-start">
      <div class="w-12 h-12 mx-auto md:mx-0 rounded-full bg-amber-700 dark:bg-amber-600 text-white flex items-center justify-center font-bold shrink-0">${i + 1}</div>
      <p class="mt-4 font-semibold text-slate-900 dark:text-white">${s.t}</p>
      <p class="mt-2 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">${s.d}</p>
    </div>`).join("");

  const strengthsHTML = T.expertise.strengths.map((s) => `
    <div class="flex items-start gap-4">
      <div class="w-9 h-9 rounded-lg bg-teal-50 dark:bg-teal-500/10 flex items-center justify-center shrink-0">
        <i data-lucide="check-circle-2" class="w-5 h-5 text-teal-700 dark:text-teal-400"></i>
      </div>
      <div>
        <p class="font-semibold text-slate-900 dark:text-white">${s.t}</p>
        <p class="text-sm text-slate-500 dark:text-slate-400 mt-0.5">${s.d}</p>
      </div>
    </div>`).join("");

  const numbersHTML = T.expertise.numbers.map((n) => `
    <div class="rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 p-6 text-center">
      <i data-lucide="${n.icon}" class="w-6 h-6 mx-auto text-amber-700 dark:text-amber-400"></i>
      <p class="mt-3 text-2xl font-extrabold text-slate-900 dark:text-white">${n.n}</p>
      <p class="text-xs mt-1 text-slate-500 dark:text-slate-400">${n.l}</p>
    </div>`).join("");

  return `
  <div class="py-20 bg-white dark:bg-slate-950">
    <div class="max-w-6xl mx-auto px-5">
      ${sectionHeadingHTML(null, T.expertise.title, T.expertise.subtitle)}
      <div class="mt-16">
        <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-10">${T.expertise.methodologyTitle}</h3>
        <div class="relative grid md:grid-cols-5 gap-8">
          <div class="hidden md:block absolute top-6 left-0 right-0 text-amber-300 dark:text-amber-700/50 -z-0">${pathLineSVG("")}</div>
          ${stepsHTML}
        </div>
      </div>
      <div class="mt-24 grid md:grid-cols-2 gap-12 items-start">
        <div>
          <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-6">${T.expertise.strengthsTitle}</h3>
          <div class="space-y-5">${strengthsHTML}</div>
        </div>
        <div>
          <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-6">${T.expertise.numbersTitle}</h3>
          <div class="grid grid-cols-2 gap-5">${numbersHTML}</div>
        </div>
      </div>
    </div>
  </div>`;
}

function servicesPageHTML() {
  const T = t();
  const chevron = isRTL() ? "chevron-left" : "chevron-right";
  const cardsHTML = T.services.list.map((s) => `
    <div class="group rounded-2xl border border-slate-200 dark:border-slate-800 p-7 hover:shadow-xl hover:shadow-slate-200/60 dark:hover:shadow-none hover:border-amber-300 dark:hover:border-amber-700 transition-all bg-white dark:bg-slate-900">
      <div class="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-500/10 flex items-center justify-center mb-5 group-hover:bg-amber-700 dark:group-hover:bg-amber-600 transition-colors">
        <i data-lucide="${s.icon}" class="w-6 h-6 text-amber-700 dark:text-amber-400 group-hover:text-white transition-colors"></i>
      </div>
      <p class="font-bold text-lg text-slate-900 dark:text-white">${s.t}</p>
      <p class="mt-2.5 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">${s.d}</p>
      <button data-action="setPage" data-value="contact" class="mt-5 flex items-center gap-1.5 text-sm font-semibold text-teal-700 dark:text-teal-400">
        ${T.cta.request} <i data-lucide="${chevron}" class="w-4 h-4"></i>
      </button>
    </div>`).join("");

  return `
  <div class="py-20 bg-white dark:bg-slate-950">
    <div class="max-w-6xl mx-auto px-5">
      ${sectionHeadingHTML(null, T.services.title, T.services.subtitle)}
      <div class="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">${cardsHTML}</div>
    </div>
  </div>`;
}

function projectsPageHTML() {
  const T = t();
  if (state.projectFilter === null) state.projectFilter = T.projects.filters[0];
  const filtered = state.projectFilter === T.projects.filters[0]
    ? T.projects.list
    : T.projects.list.filter((p) => p.cat === state.projectFilter);

  const filtersHTML = T.projects.filters.map((f) => `
    <button data-action="filterProjects" data-value="${esc(f)}"
      class="px-4 py-2 rounded-full text-sm font-medium border transition-colors ${
        state.projectFilter === f
          ? "bg-amber-700 dark:bg-amber-600 text-white border-amber-700 dark:border-amber-600"
          : "border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-amber-400"
      }">${f}</button>`).join("");

  const cardsHTML = filtered.map((p, i) => `
    <div class="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 group">
      <div class="h-40 bg-gradient-to-br ${GRADIENTS[i % GRADIENTS.length]} flex items-center justify-center relative overflow-hidden">
        <i data-lucide="route" class="w-9 h-9 text-white/70"></i>
      </div>
      <div class="p-5 bg-white dark:bg-slate-900">
        <p class="text-xs font-semibold text-amber-700 dark:text-amber-400">${p.cat}</p>
        <p class="mt-1.5 font-semibold text-slate-900 dark:text-white">${p.t}</p>
        <p class="mt-1 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">${p.d}</p>
        <div class="mt-4 flex items-center justify-between">
          <span class="text-xs text-slate-400">${p.client}</span>
          <i data-lucide="external-link" class="w-4 h-4 text-slate-400 group-hover:text-amber-600 transition-colors"></i>
        </div>
      </div>
    </div>`).join("") || `<p class="text-slate-400 text-sm col-span-full text-center py-10">—</p>`;

  return `
  <div class="py-20 bg-white dark:bg-slate-950">
    <div class="max-w-6xl mx-auto px-5">
      ${sectionHeadingHTML(null, T.projects.title, T.projects.subtitle)}
      <div class="mt-10 flex flex-wrap gap-3">${filtersHTML}</div>
      <div class="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">${cardsHTML}</div>
    </div>
  </div>`;
}

function blogPageHTML() {
  const T = t();
  const cardsHTML = T.blog.list.map((b, i) => `
    <article class="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden hover:border-amber-300 dark:hover:border-amber-700 transition-colors bg-white dark:bg-slate-900">
      <div class="h-32 bg-gradient-to-br ${GRADIENTS[i % GRADIENTS.length]}"></div>
      <div class="p-6">
        <span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400">${b.cat}</span>
        <h3 class="mt-3 font-bold text-lg text-slate-900 dark:text-white leading-snug">${b.t}</h3>
        <p class="mt-2 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">${b.excerpt}</p>
        <div class="mt-5 flex items-center justify-between text-xs text-slate-400 border-t border-slate-100 dark:border-slate-800 pt-4">
          <span class="flex items-center gap-1.5"><i data-lucide="user" class="w-3.5 h-3.5"></i>${b.author}</span>
          <span class="flex items-center gap-1.5"><i data-lucide="calendar" class="w-3.5 h-3.5"></i>${b.date}</span>
        </div>
      </div>
    </article>`).join("");

  return `
  <div class="py-20 bg-white dark:bg-slate-950">
    <div class="max-w-6xl mx-auto px-5">
      ${sectionHeadingHTML(null, T.blog.title, T.blog.subtitle)}
      <div class="mt-12 grid sm:grid-cols-2 gap-8">${cardsHTML}</div>
    </div>
  </div>`;
}

function contactPageHTML() {
  const T = t();
  const formOrSuccess = state.contactSent ? `
    <div class="flex items-center gap-3 p-5 rounded-xl bg-teal-50 dark:bg-teal-500/10 text-teal-800 dark:text-teal-300">
      <i data-lucide="check-circle-2" class="w-6 h-6 shrink-0"></i>
      <p class="text-sm font-medium">${T.contact.success}</p>
    </div>` : `
    <form data-action="submitContact" class="space-y-5">
      <div class="grid sm:grid-cols-2 gap-5">
        <div>
          <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">${T.contact.name}</label>
          <input required name="name" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500" />
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">${T.contact.email}</label>
          <input required type="email" name="email" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500" />
        </div>
      </div>
      <div class="grid sm:grid-cols-2 gap-5">
        <div>
          <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">${T.contact.phone}</label>
          <input name="phone" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500" />
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">${T.contact.subject}</label>
          <input name="subject" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500" />
        </div>
      </div>
      <div>
        <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">${T.contact.message}</label>
        <textarea required rows="5" name="message" class="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500 resize-none"></textarea>
      </div>
      <button type="submit" class="flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-500 text-white font-semibold transition-colors">
        ${T.cta.sendMsg} <i data-lucide="send" class="w-4 h-4"></i>
      </button>
    </form>`;

  return `
  <div class="py-20 bg-white dark:bg-slate-950">
    <div class="max-w-6xl mx-auto px-5">
      ${sectionHeadingHTML(null, T.contact.title, T.contact.subtitle)}
      <div class="mt-12 grid lg:grid-cols-5 gap-10">
        <div class="lg:col-span-3 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 bg-slate-50 dark:bg-slate-900/50">
          <h3 class="font-bold text-lg text-slate-900 dark:text-white mb-6">${T.contact.formTitle}</h3>
          ${formOrSuccess}
        </div>
        <div class="lg:col-span-2 space-y-5">
          <div class="rounded-2xl border border-slate-200 dark:border-slate-800 p-6">
            <h3 class="font-bold text-slate-900 dark:text-white mb-5">${T.contact.infoTitle}</h3>
            <div class="space-y-4 text-sm">
              <div class="flex items-start gap-3">
                <i data-lucide="map-pin" class="w-5 h-5 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5"></i>
                <span class="text-slate-600 dark:text-slate-300">${T.contact.address}</span>
              </div>
              <div class="flex items-start gap-3">
                <i data-lucide="phone" class="w-5 h-5 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5"></i>
                <span class="text-slate-600 dark:text-slate-300" dir="ltr">+966 11 234 5678</span>
              </div>
              <div class="flex items-start gap-3">
                <i data-lucide="mail" class="w-5 h-5 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5"></i>
                <span class="text-slate-600 dark:text-slate-300" dir="ltr">hello@apath.co</span>
              </div>
              <div class="flex items-start gap-3">
                <i data-lucide="clock" class="w-5 h-5 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5"></i>
                <span class="text-slate-600 dark:text-slate-300">${T.contact.hours}</span>
              </div>
            </div>
          </div>
          <div class="rounded-2xl h-48 bg-gradient-to-br from-teal-600 to-slate-800 flex items-center justify-center">
            <i data-lucide="compass" class="w-10 h-10 text-white/70"></i>
          </div>
        </div>
      </div>
    </div>
  </div>`;
}

const pageRenderers = {
  home: homePageHTML,
  expertise: expertisePageHTML,
  services: servicesPageHTML,
  projects: projectsPageHTML,
  blog: blogPageHTML,
  contact: contactPageHTML,
};

/* ======================= RENDER / MOUNT ======================= */
function render() {
  document.documentElement.dir = t().dir;
  document.documentElement.lang = state.lang;
  document.documentElement.classList.toggle("dark", state.theme === "dark");

  const root = document.getElementById("root");
  root.innerHTML = `
    <div class="min-h-screen bg-white dark:bg-slate-950 transition-colors">
      ${headerHTML()}
      ${pageRenderers[state.page]()}
      ${footerHTML()}
    </div>`;

  if (window.lucide) lucide.createIcons();
}

/* ======================= EVENT DELEGATION ======================= */
document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-action]");
  if (!el) return;
  const action = el.getAttribute("data-action");
  const value = el.getAttribute("data-value");

  switch (action) {
    case "setPage":
      state.page = value;
      state.menuOpen = false;
      state.contactSent = false;
      window.scrollTo({ top: 0, behavior: "smooth" });
      render();
      break;
    case "toggleLang":
      state.lang = state.lang === "ar" ? "en" : "ar";
      state.projectFilter = null;
      render();
      break;
    case "toggleTheme":
      state.theme = state.theme === "light" ? "dark" : "light";
      render();
      break;
    case "toggleMenu":
      state.menuOpen = !state.menuOpen;
      render();
      break;
    case "filterProjects":
      state.projectFilter = value;
      render();
      break;
  }
});

document.addEventListener("submit", (e) => {
  const form = e.target.closest("[data-action='submitContact']");
  if (!form) return;
  e.preventDefault();
  state.contactSent = true;
  render();
});

render();
</script>

<?php
get_footer();
